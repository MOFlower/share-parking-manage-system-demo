package top.moflowerlkh.shareparkingdemo.service;

public interface CarService {
}
